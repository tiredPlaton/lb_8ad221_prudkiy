package stringcheck;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите строку для проверки:");
        String input = scanner.nextLine();

        BracketChecker<String> bracketChecker = new BracketChecker<>();
        NumberChecker<String> numberChecker = new NumberChecker<>();

        bracketChecker.add(input);
        numberChecker.add(input);

        System.out.println("Проверка на правильность скобочной последовательности: " + bracketChecker.check());
        System.out.println("Проверка на правильность записи числа: " + numberChecker.check());
    }
}
