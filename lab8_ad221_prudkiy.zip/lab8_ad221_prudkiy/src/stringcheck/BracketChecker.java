package stringcheck;

import stringcheck.DataStructure;

public class BracketChecker<T> implements DataStructure<T> {
    private Object[] array;
    private int size;

    public BracketChecker() {
        array = new Object[10];
        size = 0;
    }

    @Override
    public void add(T t) {
        if (size == array.length) {
            Object[] newArray = new Object[array.length * 2];
            System.arraycopy(array, 0, newArray, 0, array.length);
            array = newArray;
        }
        array[size++] = t;
    }

    @Override
    public T remove() {
        if (size == 0) {
            throw new RuntimeException("The structure is empty");
        }
        @SuppressWarnings("unchecked")
        T t = (T) array[--size];
        return t;
    }

    @Override
    public boolean check() {
        String str = (String) remove();
        int balance = 0;
        for (char c : str.toCharArray()) {
            if (c == '(') {
                balance++;
            } else if (c == ')') {
                balance--;
            } else {
                return false; // Недопустимый символ
            }
            if (balance < 0) {
                return false; // Закрывающая скобка перед открывающей
            }
        }
        return balance == 0; // Если баланс равен 0, скобки сбалансированы
    }
}
