package stringcheck;

public class NumberChecker<T> implements DataStructure<T> {
    private Object[] array;
    private int size;

    public NumberChecker() {
        array = new Object[10];
        size = 0;
    }

    @Override
    public void add(T t) {
        if (size == array.length) {
            Object[] newArray = new Object[array.length * 2];
            System.arraycopy(array, 0, newArray, 0, array.length);
            array = newArray;
        }
        array[size++] = t;
    }

    @Override
    public T remove() {
        if (size == 0) {
            throw new RuntimeException("The structure is empty");
        }
        @SuppressWarnings("unchecked")
        T t = (T) array[--size];
        return t;
    }

    @Override
    public boolean check() {
        String str = (String) remove();
        if (str.length() > 1 && str.charAt(0) == '0') {
            return false; // Первая цифра не может быть 0
        }
        for (char c : str.toCharArray()) {
            if (!Character.isDigit(c)) {
                return false; // Недопустимый символ
            }
        }
        return true; // Все символы - цифры
    }
}
