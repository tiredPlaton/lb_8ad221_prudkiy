package stringcheck;

public interface DataStructure<T> {
    void add(T t);
    T remove();
    boolean check();
}
